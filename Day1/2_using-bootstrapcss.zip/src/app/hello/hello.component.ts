import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hello',
  template: `
    <h1 class="text-info">
      Hello World!
    </h1>
  `,
  styles: []
})
export class HelloComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
