import { Component, OnInit, AfterViewInit, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styles: []
})
export class RootComponent implements OnInit, AfterViewInit {
  private message: string;
  private flag: boolean;
  private imageSource: any;
  private h: number;
  private w: number;

  constructor(private ngZone: NgZone) { }

  ngAfterViewInit(): void {
    // document.getElementById("btnJS").addEventListener("click", () => {
    //   this.message = new Date().toTimeString();
    //   console.log(this.message);
    // });

    this.ngZone.runOutsideAngular(() => {
      document.getElementById("btnJS").addEventListener("click", () => {
        this.message = new Date().toTimeString();
        console.log(this.message);
      });
    });
  }

  ngOnInit() {
    this.message = "Hello World!";
    this.flag = false;
    this.imageSource = require('../../assets/image1.jpg');
    this.h = 200;
    this.w = 200;
  }

  doChange() {
    this.message = new Date().toTimeString();
  }

  doUpdate(city: string) {
    this.message = `You are from, ${city}`;
  }
}
