import { BrowserModule } from '@angular/platform-browser';
import { APP_BOOTSTRAP_LISTENER, ComponentRef, NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { FormsModule } from '@angular/forms';
import { AssignOneComponent } from './assign-one/assign-one.component';
import { AssignTwoComponent } from './assign-two/assign-two.component';

@NgModule({
  declarations: [RootComponent, AssignOneComponent, AssignTwoComponent],
  imports: [BrowserModule, FormsModule],
  providers: [{
    provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
      return (component: ComponentRef<any>) => {
        console.log(component);
      }
    }
  }],
  bootstrap: [RootComponent]
})
export class AppModule { }
