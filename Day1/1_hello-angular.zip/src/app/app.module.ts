// -------------------------------------------------------------- Default / Auto Bootstrap

// import { BrowserModule } from '@angular/platform-browser';
// import { NgModule } from '@angular/core';
// import { HelloComponent } from './hello/hello.component';

// @NgModule({
//   declarations: [HelloComponent],
//   imports: [BrowserModule],
//   bootstrap: [HelloComponent]
// })
// export class AppModule { }

// -------------------------------------------------------------- Manual Bootstrap

import { BrowserModule } from '@angular/platform-browser';
import { ApplicationRef, DoBootstrap, NgModule } from '@angular/core';
import { HelloComponent } from './hello/hello.component';

@NgModule({
  declarations: [HelloComponent],
  imports: [BrowserModule],
  entryComponents: [HelloComponent]
})
export class AppModule implements DoBootstrap {
  ngDoBootstrap(appRef: ApplicationRef): void {
    const container = document.querySelector("#container");

    const helloTag = document.createElement('app-hello');
    helloTag.innerText = "Hello Tag Added Manually";
    container.appendChild(helloTag);

    appRef.bootstrap(HelloComponent);
  }
}
