// // 1. Element Inline Style
// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-comp-one',
//   template: `
//     <h1 class="text-info">Hello from Component One</h1>
//     <h2 style="border-style: solid; border-width: 2px; border-color: blue;">From Component One</h2>
//   `
// })
// export class CompOneComponent { }

// // 2. Template Inline Style
// import { Component, ViewEncapsulation } from '@angular/core';

// @Component({
//   selector: 'app-comp-one',
//   template: `
//     <style>
//       .card {
//         border-style: solid; 
//         border-width: 2px; 
//         border-color: blue;
//       }
//     </style>
//     <h1 class="text-info">Hello from Component One</h1>
//     <h2 class="card">From Component One</h2>
//   `,
//   encapsulation: ViewEncapsulation.Emulated
// })
// export class CompOneComponent { }

// // 3. Component Inline Style
// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-comp-one',
//   template: `
//     <h1 class="text-info">Hello from Component One</h1>
//     <h2 class="card">From Component One</h2>
//   `,
//   styles: [`
//     .card {
//       border-style: solid; 
//       border-width: 2px; 
//       border-color: blue;
//     }
//   `]
// })
// export class CompOneComponent { }

// 4. External CSS
import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  template: `
    <h1 class="text-info">Hello from Component One</h1>
    <h2 class="card">From Component One</h2>
  `,
  styleUrls: ['./comp-one.component.css']
})
export class CompOneComponent { }