import { BrowserModule } from '@angular/platform-browser';
import { APP_BOOTSTRAP_LISTENER, ComponentRef, NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { MOneModule } from './m-one/m-one.module';
import { MTwoModule } from './m-two/m-two.module';

@NgModule({
  declarations: [RootComponent],
  imports: [BrowserModule, MOneModule, MTwoModule],
  providers: [{
    provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
      return (component: ComponentRef<any>) => {
        // console.log("Loaded....");
        console.log(component);
      }
    }
  }],
  bootstrap: [RootComponent]
})
export class AppModule { }
