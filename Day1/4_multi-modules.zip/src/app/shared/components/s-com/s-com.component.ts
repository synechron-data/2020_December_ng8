import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-s-com',
  template: `
    <h3 class="text-danger">
      Hello from Shared Component!
    </h3>
  `,
  styles: []
})
export class SComComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
