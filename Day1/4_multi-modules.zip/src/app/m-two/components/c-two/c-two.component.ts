import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-two',
  template: `
    <h2 class="text-success">Hello from Component Two - Module Two!</h2>
    <app-s-com></app-s-com>
  `
})
export class CTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
