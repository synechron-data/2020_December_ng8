import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CTwoComponent } from './components/c-two/c-two.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [CTwoComponent],
  imports: [CommonModule, SharedModule],
  exports: [CTwoComponent]
})
export class MTwoModule { }
