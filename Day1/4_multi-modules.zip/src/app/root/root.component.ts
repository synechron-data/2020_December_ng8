import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
        <app-c-one></app-c-one>
        <app-c-two></app-c-two>
    </div>
  `,
  styles: []
})
export class RootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
