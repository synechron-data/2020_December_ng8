import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { COneComponent } from './components/c-one/c-one.component';
import { HelloComponent } from './components/hello/hello.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [COneComponent, HelloComponent],
  imports: [CommonModule, SharedModule],
  exports: [COneComponent]
})
export class MOneModule { }
