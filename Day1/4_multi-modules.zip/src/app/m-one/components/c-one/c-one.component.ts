import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-one',
  template: `
    <h2 class="text-info">Hello from Component One - Module One!</h2>
    <app-hello></app-hello>
    <app-s-com></app-s-com>
  `
})
export class COneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
