import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Post } from '../models/post.model';
import { PostService } from '../services/post.service';

@Component({
    selector: 'app-root',
    templateUrl: 'root.component.html',
    providers: [PostService]
})

export class RootComponent implements OnInit, OnDestroy {
    url: string;
    message: string;
    posts: Array<Post>;
    get_sub: Subscription;
    ins_sub: Subscription;
    del_sub: Subscription;

    constructor(private _pService: PostService) {
        this.url = "https://jsonplaceholder.typicode.com/posts";
        this.message = "Loading Data, please wait....";
    }

    insertPost() {
        let newPost: Post = {
            userId: 1,
            id: 0,
            title: "Test",
            body: "Test"
        };

        this.ins_sub = this._pService.insertPost(newPost).subscribe(resData => {
            this.posts.unshift(resData);
            this.message = "Record Inserted";
            setTimeout(() => {
                this.message = "";
            }, 2000);
        }, (err: string) => {
            this.message = err;
        });
    }

    deletePost(id: number, event: Event) {
        event.preventDefault();

        this.del_sub = this._pService.deletePost(id).subscribe(() => {
            this.posts = [...this.posts.filter(p => p.id !== id)];
            this.message = "Record Deleted";
            setTimeout(() => {
                this.message = "";
            }, 2000);
        }, (err: string) => {
            this.message = err;
        });
    }

    ngOnInit() {
        this.get_sub = this._pService.getPosts().subscribe(resData => {
            this.posts = [...resData];
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }

    ngOnDestroy(): void {
        this.get_sub.unsubscribe();
        this.ins_sub.unsubscribe();
        this.del_sub.unsubscribe();
    }
}
// -----------------------------------------------------------------------
// import { HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from '../models/post.model';
// import { PostService } from '../services/post.service';

// @Component({
//     selector: 'app-root',
//     templateUrl: 'root.component.html',
//     providers: [PostService]
// })

// export class RootComponent implements OnInit, OnDestroy {
//     url: string;
//     message: string;
//     posts: Array<Post>;
//     get_sub: Subscription;

//     constructor(private _pService: PostService) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait....";
//     }

//     ngOnInit() {
//         this.get_sub = this._pService.getPosts().subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub.unsubscribe();
//     }
// }

// ---------------------------------------------------------------------------------
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from '../models/post.model';

// @Component({
//     selector: 'app-root',
//     templateUrl: 'root.component.html'
// })

// export class RootComponent implements OnInit, OnDestroy {
//     url: string;
//     message: string;
//     posts: Array<Post>;
//     get_sub: Subscription;

//     constructor(private _httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait....";
//     }

//     ngOnInit() {
//         this.get_sub = this._httpClient.get<Array<Post>>(this.url).subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub.unsubscribe();
//     }
// }