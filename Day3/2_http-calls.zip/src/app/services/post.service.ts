import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Post } from "../models/post.model";
import { catchError, delay, retry } from "rxjs/operators";
import { Observable, throwError } from "rxjs";

@Injectable()
export class PostService {
    private url: string;

    constructor(private _httpClient: HttpClient) {
        this.url = "https://jsonplaceholder.typicode.com/posts";
    }

    // getPosts() {
    //     return this._httpClient.get<Array<Post>>(this.url);
    // }

    getPosts() {
        return this._httpClient.get<Array<Post>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('getPosts', []))
        );
    }

    insertPost(post: Post) {
        return this._httpClient.post<Post>(this.url, post).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('insertPost', post))
        );
    }

    deletePost(postId: number) {
        var deleteUrl = `${this.url}/${postId}`;

        return this._httpClient.delete(deleteUrl).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('deletePost'))
        );
    }

    private _handleError<T>(operation = "operation", result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            // console.log(err);
            // console.error(`${operation} failed: ${err.message}`);
            return throwError('Connection Error, please try again later....');
        }
    }
}