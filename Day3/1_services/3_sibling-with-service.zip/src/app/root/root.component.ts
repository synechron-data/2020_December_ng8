import { Component, OnInit } from '@angular/core';
import { AuthorService } from '../services/author.service';

@Component({
    selector: 'app-root',
    templateUrl: 'root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [AuthorService]
})

export class RootComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }
}