import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'admin',
  templateUrl: './admin.component.html',
  // providers: [UsersService]
})
export class AdminComponent implements OnInit {
  users: Array<any>;
  message: string;
  gu_sub: Subscription;

  constructor(private _uService: UsersService) { }

  ngOnInit() {
    this.gu_sub = this._uService.getAllUsers().subscribe(resData => {
      this.users = resData.data;
      this.message = "";
    }, (err: string) => {
      this.message = err;
    });
  }

}
