import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LazyOneComponent } from './components/lazy-one/lazy-one.component';
import { RouterModule } from '@angular/router';
import { lazyRoutes } from './lazy.routes';

@NgModule({
  declarations: [LazyOneComponent],
  imports: [CommonModule, RouterModule.forChild(lazyRoutes)],
  exports: [RouterModule]
})
export class LazyModule { }
