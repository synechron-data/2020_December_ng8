class User {
    constructor(uname, uemail) {
        this.username = uname;
        this.email = uemail;
    }
}

module.exports = User;