import { Component, OnInit } from '@angular/core';
import { Observable, Observer, Subject, of } from 'rxjs';
import { map, reduce, filter } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styles: []
})
export class RootComponent implements OnInit {
  // subject: Subject<number>;

  constructor() {
    // let numObservable = of(10, 20, 33, 40, 53, 60, 73);

    // // numObservable.subscribe(x => console.log(x));

    // let processedObservable = numObservable.pipe(
    //   filter(n => n % 2 == 0),
    //   map(n => n * 10),
    //   reduce((acc, num) => acc * num)
    // );

    // processedObservable.subscribe(x => console.log(x));

    // this.subject = new Subject<number>();

    // setInterval(() => {
    //   this.subject.next(Math.random());
    // }, 2000);

    // this.subject.subscribe(data => {
    //   console.log("Subscriber 1, Output - ", data);
    // });

    // this.subject.subscribe(data => {
    //   console.log("Subscriber 2, Output - ", data);
    // });

    // this.getObservable().subscribe(data => {
    //   console.log("Observable Output, S1 - ", data);
    // }, err => {
    //   console.error("Observable Error - ", err);
    // });

    // this.getObservable().subscribe(data => {
    //   console.log("Observable Output, S2 - ", data);
    // }, err => {
    //   console.error("Observable Error - ", err);
    // });

    // this.getPromise().then(data => {
    //   console.log("Promise Output - ", data);
    // }, err => {
    //   console.error("Promise Error - ", err);
    // });
  }

  ngOnInit() {
  }

  getObservable(): Observable<number> {
    return Observable.create((ob: Observer<number>) => {
      setInterval(function () {
        ob.next(Math.random());
      }, 2000);
    });
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      setInterval(function () {
        // console.log("Set Interval Executed....");
        resolve(Math.random());
      }, 2000);
    });
  }
}
