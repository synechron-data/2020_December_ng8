import { BrowserModule } from '@angular/platform-browser';
import { APP_BOOTSTRAP_LISTENER, ComponentRef, NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TemplatedFormComponent } from './templated-form/templated-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { ValidationFormComponent } from './validation-form/validation-form.component';

@NgModule({
  declarations: [RootComponent, TemplatedFormComponent, ReactiveFormComponent, ValidationFormComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  providers: [{
    provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
      return (component: ComponentRef<any>) => {
        console.log(component);
      }
    }
  }],
  bootstrap: [RootComponent]
})
export class AppModule { }
