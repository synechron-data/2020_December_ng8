import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent implements OnInit {
  @Input() personList:Array<string>;
  selected: string;

  constructor() { }

  ngOnInit() {
  }

  select(name: string, event: Event) {
    this.selected = name;
    event.preventDefault();
  }
}
